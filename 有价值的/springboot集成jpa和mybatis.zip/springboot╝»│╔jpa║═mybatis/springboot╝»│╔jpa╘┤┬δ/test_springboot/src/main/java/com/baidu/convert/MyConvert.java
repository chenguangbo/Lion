package com.baidu.convert;

import org.apache.commons.lang3.StringUtils;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

/**
 * 转换器类
 * 
 * @author CGB
 */
@Component // 这个注解将这个转换器交给springboot容器管理
public class MyConvert implements Converter<String, String> {

	@Override
	public String convert(String source) {
		if (StringUtils.isNotBlank(source)) {
			return source.trim();
		}
		return null;
	}
}
