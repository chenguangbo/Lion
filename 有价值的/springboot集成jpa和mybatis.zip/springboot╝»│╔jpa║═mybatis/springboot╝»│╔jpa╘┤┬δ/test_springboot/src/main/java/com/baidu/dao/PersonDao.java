package com.baidu.dao;

import java.io.Serializable;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.baidu.pojo.Person;

//要操作的实体类           实体类的主键类型		
public interface PersonDao extends JpaRepository<Person, Serializable> {

	// 根据人的名字精确查找
	List<Person> findByName(String name);
	// List<Person> findByNameLike(String name); //根据人的名字模糊查找

	// 根据介绍模糊查找
	List<Person> findByIntroduceLike(String introduce);

	// 根据名称查找或者根据介绍查找
	List<Person> findByNameAndIntroduceLike(String name, String introduce);

	// List<Person> findByNameAndIntroduceLike(String name,String introduce);
	// 根据名字和介绍查找

}
