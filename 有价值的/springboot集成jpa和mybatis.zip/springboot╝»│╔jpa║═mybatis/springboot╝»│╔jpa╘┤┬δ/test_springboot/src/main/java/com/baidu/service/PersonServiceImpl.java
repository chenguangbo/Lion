package com.baidu.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.baidu.dao.PersonDao;
import com.baidu.pojo.Person;

@Service
public class PersonServiceImpl implements PersonService {

	@Autowired
	private PersonDao personDao;
	
	@Override
	public List<Person> findAll() {
		return personDao.findAll();
	}

	@Override
	public List<Person> findByNameOrIntroduceLike(String name, String introduce) {
		if(name == null && introduce == null){
			return personDao.findAll();
		}
		if(name==null){
			return personDao.findByIntroduceLike("%"+introduce+"%");
		}
		if(introduce == null ){
			return personDao.findByName(name);
		}
		return personDao.findByNameAndIntroduceLike(name, "%"+introduce+"%");
	}

	
	
}
