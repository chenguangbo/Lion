package com.baidu.service;

import java.util.List;

import com.baidu.pojo.Person;

public interface PersonService {

	List<Person> findAll();
	
	List<Person> findByNameOrIntroduceLike(String name,String introduce);
	
}
