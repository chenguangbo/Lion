package com.baidu.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.baidu.pojo.Person;
import com.baidu.service.PersonService;

@Controller
public class PersonController {

	@Autowired
	private PersonService personService;
	
	@GetMapping(value="/listPerson")
	public String listPerson(Model model, String name,String introduce){
		//List<Person> listPerson = personService.findAll();
		List<Person> listPerson = personService.findByNameOrIntroduceLike(name, introduce);
		
		model.addAttribute("listPerson", listPerson);
		model.addAttribute("name", name);
		model.addAttribute("introduce", introduce);
		//打印查询信息
		System.out.println(model);
		for (Person person : listPerson) {
			System.out.println(person.toString());
		}																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																												
		return "listPerson";
	}
	
	/**
	 * 这个方法是测试程序通不通
	 * @return
	 */
	@GetMapping(value="/")
	public String erson(){
		List<Person> listPerson = personService.findAll();
		
		for (Person person : listPerson) {
			System.out.println(person.toString());
		}
		return "abc";
	}
	
	
}
