package com.trs.service;

import java.util.List;

import com.trs.pojo.Person;
import com.trs.pojo.QueryVo;

public interface PersonService {

	List<Person> findAll();
	
	List<Person> findByNameAndIntroduceLike(QueryVo qv);
}
