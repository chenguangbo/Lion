package com.trs.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.trs.pojo.Person;
import com.trs.pojo.QueryVo;

@Mapper
public interface PersonDao {

	List<Person> findAll();
	
	List<Person> findByNameAndIntroduceLike(QueryVo qv);
}
