package com.trs.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.trs.dao.PersonDao;
import com.trs.pojo.Person;
import com.trs.pojo.QueryVo;

@Service
public class PersonServiceImpl implements PersonService{

	@Autowired
	private PersonDao personDao;
	
	@Override
	public List<Person> findAll() {

		return personDao.findAll();
	}

	@Override
	public List<Person> findByNameAndIntroduceLike(QueryVo qv) {

		return personDao.findByNameAndIntroduceLike(qv);
	}

}
