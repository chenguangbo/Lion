package com.trs.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.trs.pojo.Person;
import com.trs.pojo.QueryVo;
import com.trs.service.PersonService;

@Controller
public class PersonController {

	@Autowired
	private PersonService personservice;
	
	@GetMapping(value="/listPerson")
	public String index(Model model){
			
		List<Person> personList = personservice.findAll();
		for (Person person : personList) {
			System.out.println(person);
		}
		model.addAttribute("personList", personList);
		
		return "listPerson";
	}
	
	
	@GetMapping(value="/personList")
	public String ind(Model model,String name,String introduce){
			
		
		QueryVo qv = new QueryVo();
		qv.setName(name);
		qv.setIntroduce(introduce);
		System.err.println(name+"===="+introduce);
		List<Person> personList = personservice.findByNameAndIntroduceLike(qv );
		
		model.addAttribute("personList", personList);
		model.addAttribute("name", name);
		model.addAttribute("introduce",introduce);
		return "listPerson";
	}
	
}
